﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace stopwatch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        System.Diagnostics.Stopwatch watch= new System.Diagnostics.Stopwatch();
        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan newtimespan=watch.Elapsed;
            lblmilli.Text=newtimespan.Milliseconds.ToString();
            lblsec.Text=newtimespan.Seconds.ToString();
            lblmin.Text=newtimespan.Minutes.ToString();
            lblhrs.Text=newtimespan.Hours.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            watch.Start();
            timer1.Enabled= true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            watch.Stop();
            timer1.Enabled= false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            watch.Start();
            timer1.Enabled= true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            watch.Reset();
            timer1.Enabled= false;
            lblmilli.Text = "0";
            lblsec.Text = "0";
            lblmin.Text = "0";
            lblhrs.Text = "0";
        }
    }
}
